<?php

namespace tests\functional;

use yii2lab\test\enums\TypeEnum;
use yii2lab\test\helpers\CurrentIdTestHelper;
use yii2lab\test\helpers\TestHelper;
use yii2lab\test\Test\BaseActiveApiTest;
use yii2rails\extension\yii\helpers\FileHelper;
use yii2module\account\domain\v3\helpers\test\RegistrationTestHelper;

class ContactPersonalTest extends BaseActiveApiTest
{

    public $package = 'api';
    public $point = 'v1';

    private $contactSchema = [
        'id' => TypeEnum::INTEGER,
        'person_id' => TypeEnum::INTEGER,
        'first_name' => TypeEnum::STRING,
        'last_name' => TypeEnum::STRING,
        'middle_name' => TypeEnum::STRING,
        'phone' => TypeEnum::STRING,
        'email' => TypeEnum::STRING,
        'kind' => TypeEnum::STRING,
        'status' => TypeEnum::INTEGER,
        'updated_at' => TypeEnum::TIME,
        'created_at' => TypeEnum::TIME,
    ];

    public function testLoadFixture()
    {
        TestHelper::copySqlite(FileHelper::up(__DIR__), false);
    }

    public function testCreateUser()
    {
        RegistrationTestHelper::registration();
    }

    public function testCreate()
    {
        $this->authByNewUser();
        $this->createEntity('contact-personal', [
            'phone' => '76662429296',
            'email' => 'tester122@yuwert.kz',
            'first_name' => 'tester122',
            'last_name' => 'testerov',
            'middle_name' => 'testerovich',
        ], true);
        $this->createEntity('contact-personal', [
            'phone' => '77771242111',
            'email' => 'admin22@yuwert.kz',
            'first_name' => 'admin22',
            'last_name' => 'adminov',
            'middle_name' => 'adminovich',
        ], true);
        $this->createEntity('contact-personal', [
            'phone' => '77712421114',
            'email' => 'reporter133@yuwert.kz',
            'first_name' => 'reporter122',
            'last_name' => 'reporterov1',
            'middle_name' => 'reporterovich1',
        ], true);
        $this->createEntity('contact-personal', [
            'phone' => '77712421115',
            'email' => 'reporter222@yuwert.kz',
            'first_name' => 'reporter222',
            'last_name' => 'reporterov2',
            'middle_name' => 'reporterovich2',
        ], true);
    }

    public function testAll()
    {
        $this->authByNewUser();
        $this->readCollection('contact-personal', [], $this->contactSchema, 4);
        $this->readCollection('contact-personal', ['fields' => 'id,person_id'], $this->contactSchema, 4);
    }

    public function testView()
    {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $this->readEntity('contact-personal', $id, $this->contactSchema);
        $this->readEntity('contact-personal', $id, $this->contactSchema, ['fields' => 'id,person_id']);
    }

    public function testSearchEmail()
    {
        $this->authByNewUser();
        $this->readCollection('contact-personal', ['search[email]' => 'tester',], $this->contactSchema, 1);
    }

    public function testSearchByFirstName()
    {
        $this->authByNewUser();
        $this->readCollection('contact-personal', ['search[first_name]' => 'tes'], $this->contactSchema, 1);
        $this->readCollection('contact-personal', ['search[first_name]' => 'reporter'], $this->contactSchema, 2);
    }

    public function testSearchByName()
    {
        $this->authByNewUser();
        $this->readCollection('contact-personal', ['search[name]' => 'tes'], $this->contactSchema, 1);
        $this->readCollection('contact-personal', ['search[name]' => 'reporter'], $this->contactSchema, 2);
    }

    public function testSearchByPhone()
    {
        $this->authByNewUser();
        $this->readCollection('contact-personal', ['search[phone]' => '2429296'], $this->contactSchema, 1);
        $this->readCollection('contact-personal', ['search[phone]' => '242111'], $this->contactSchema, 3);
    }

    public function testUpdate()
    {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $this->updateEntity('contact-personal', $id, [
            'phone' => '77779109296',
            'email' => 'user@yuwert.kz',
            'first_name' => 'user',
            'last_name' => 'userov',
            'middle_name' => 'userovich',
        ]);
        $actual = $this->readEntity('contact-personal', $id, $this->contactSchema);
        $this->tester->assertArraySubset([
            'phone' => '77779109296',
            'email' => 'user@yuwert.kz',
            'first_name' => 'user',
            'last_name' => 'userov',
            'middle_name' => 'userovich',
        ], $actual);
    }

    public function testDelete()
    {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $this->deleteEntity('contact-personal', $id);
        $this->readNotFoundEntity('contact-personal', $id);
    }

}
