<?php

namespace tests\functional\mail;

use api\tests\schemas\MailSchema;
use yii2lab\test\enums\TypeEnum;
use yii2lab\test\helpers\CurrentIdTestHelper;
use yii2lab\test\helpers\TestHelper;
use yii2lab\test\Test\BaseActiveApiTest;
use yii2rails\extension\yii\helpers\FileHelper;
use yii2module\account\domain\v3\helpers\test\CurrentPhoneTestHelper;
use yii2module\account\domain\v3\helpers\test\RegistrationTestHelper;

class DiscussionMailTest extends BaseActiveApiTest
{

    public $package = 'api';
    public $point = 'v1';

    public function testLoadFixture()
    {
        TestHelper::copySqlite(FileHelper::up(__DIR__), false);
    }

    public function testCreateUser()
    {
        RegistrationTestHelper::registration();
    }

    public function testCreate() {
        $phone = CurrentPhoneTestHelper::get();
        $this->authByNewUser();
        $this->createEntity('discussion', [
            'subject' => 'test discussion subject ' . $phone,
            'description' => 'test discussion description',
            'member_emails' =>
                'tester1@yuwert.kz,tester2' . '@' . TestHelper::getServerConfig('mailDomainCorparate') . ',reporter1' . '@' . TestHelper::getServerConfig('mailDomainCorparate'),
        ], true);
    }

    public function testSendMailToDiscussionByDiscussionId() {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $this->createEntity('mail', [
            //'to' => 'tester1' . '@' . TestHelper::getServerConfig('mailDomainCorparate'),
            //'subject' => 'subject test',
            'content' => 'content test to dialog',
            'discussion_id' => $id,
        ]);
    }

    public function testAllMailsByDialogId()
    {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $this->readCollection('mail', ['discussion_id' => $id], MailSchema::$flow, 1);
    }

    public function testClearDiscussionMessages()
    {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $this->deleteEntity('discussion-message', $id);
    }

    public function testAllMailsByDialogIdAfterClean()
    {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $this->readCollection('mail', ['discussion_id' => $id], MailSchema::$flow, 0);
    }

}
