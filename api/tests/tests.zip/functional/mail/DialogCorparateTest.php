<?php

namespace tests\functional\mail;

use api\tests\schemas\BoxSchema;
use api\tests\schemas\CompanySchema;
use api\tests\schemas\DialogSchema;
use api\tests\schemas\DomainSchema;
use api\tests\schemas\UserSchema;
use yii2lab\rest\domain\entities\RequestEntity;
use yii2lab\test\helpers\CurrentIdTestHelper;
use yii2lab\test\helpers\TestHelper;
use yii2lab\test\Test\BaseActiveApiTest;
use yii2rails\extension\web\enums\HttpMethodEnum;
use yii2rails\extension\yii\helpers\FileHelper;
use yii2module\account\domain\v3\helpers\test\CurrentPhoneTestHelper;
use yii2module\account\domain\v3\helpers\test\RegistrationTestHelper;

class DialogCorparateTest extends BaseActiveApiTest
{

    public $package = 'api';
    public $point = 'v1';

    public function testClean() {
        $this->cleanAllDialogs('at_tester1');
        $this->cleanAllDialogs('at_tester2');
    }

    public function testCreate() {
        $this->authByAtUser('at_tester1');
        $this->createEntity('dialog', [
            'contractor' => 'at_tester2@test.company',
        ], true);
        $this->createEntity('dialog', [
            'contractor' => 'at_dev1@test.company',
        ], true);
        $this->createEntity('dialog', [
            'contractor' => 'tester1' . '@' . TestHelper::getServerConfig('mailDomainCorparate'),
        ], true);

        $this->authByAtUser('at_tester1');
        $this->readCollection('dialog', [], DialogSchema::$dialog, 3);
        $this->authByAtUser('at_tester2');
        $this->readCollection('dialog', [], DialogSchema::$dialog, 1);
    }

    public function testAll() {
        $this->authByAtUser('at_tester1');
        $actual = $this->readCollection('dialog', [], DialogSchema::$dialog, 3);
        /*$this->tester->assertArraySubset([
            [
                'id' => 103,
                'actor' => 'at_tester1@test.company',
                'contractor' => 'at_tester2@test.company',
                'created_at' => '2019-04-30T08:17:24+0000',
                'updated_at' => '2019-04-30T08:17:24+0000',
                'status' => 1,
                'last_message' => null,
                'new_message_count' => 0,
                'flagged' => false,
                'full_name' => 'tester autotest',
                'post_name' => null,
                'division_name' => null,
                'is_corparate_person' => false,
            ],
            [
                'id' => 105,
                'actor' => 'at_tester1@test.company',
                'contractor' => 'at_dev1@test.company',
                'created_at' => '2019-04-30T08:17:24+0000',
                'updated_at' => '2019-04-30T08:17:24+0000',
                'status' => 1,
                'last_message' => null,
                'new_message_count' => 0,
                'flagged' => false,
                'full_name' => 'developer autotest',
                'post_name' => null,
                'division_name' => null,
                'is_corparate_person' => false,
            ],
            [
                'id' => 106,
                'actor' => 'at_tester1@test.company',
                'contractor' => 'tester1' . '@' . TestHelper::getServerConfig('mailDomainCorparate'),
                'created_at' => '2019-04-30T08:17:24+0000',
                'updated_at' => '2019-04-30T08:17:24+0000',
                'status' => 1,
                'last_message' => null,
                'new_message_count' => 0,
                'flagged' => false,
                'full_name' => 'Tester 1 Tester',
                'post_name' => 'Тестировщик',
                'division_name' => 'Отдел тестирования',
                'is_corparate_person' => true,
            ],
        ], $actual);*/
        //d($actual);
    }

    private function cleanAllDialogs($login) {
        $this->authByAtUser($login);
        $dialogCollection = $this->readCollection('dialog', [], []);
        foreach ($dialogCollection as $dialog) {
            $this->send('dialog' . SL . $dialog['id'], HttpMethodEnum::DELETE);
        }
        $this->readCollection('dialog', [], DialogSchema::$dialog, 0);
    }

}
