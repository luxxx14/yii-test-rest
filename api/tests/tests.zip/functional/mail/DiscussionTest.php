<?php

namespace tests\functional\mail;

use yii2lab\test\enums\TypeEnum;
use yii2lab\test\helpers\CurrentIdTestHelper;
use yii2lab\test\helpers\TestHelper;
use yii2lab\test\Test\BaseActiveApiTest;
use yii2rails\extension\yii\helpers\FileHelper;
use yii2module\account\domain\v3\helpers\test\CurrentPhoneTestHelper;
use yii2module\account\domain\v3\helpers\test\RegistrationTestHelper;

class DiscussionTest extends BaseActiveApiTest
{

    public $package = 'api';
    public $point = 'v1';

    private $discussionSchema = [
        'id' => TypeEnum::INTEGER,
        'corporate_client_id' => [TypeEnum::INTEGER,TypeEnum::NULL],
        'subject' => TypeEnum::STRING,
        'description' => TypeEnum::STRING,
        'members' => TypeEnum::NULL,
        'mails' => TypeEnum::NULL,
        'status' => TypeEnum::INTEGER,
        'created_at' => TypeEnum::TIME,
        'updated_at' => TypeEnum::TIME,
        'last_message' => TypeEnum::STRING,
    ];

    public function testLoadFixture()
    {
        TestHelper::copySqlite(FileHelper::up(__DIR__), false);
    }

    public function testCreateUser()
    {
        RegistrationTestHelper::registration();
    }

    public function testCreate() {
        $phone = CurrentPhoneTestHelper::get();
        $this->authByNewUser();
        $this->createEntity('discussion', [
            'subject' => 'test discussion subject ' . $phone,
            'description' => 'test discussion description',
            'member_emails' =>
                'tester1@yuwert.kz,tester2' . '@' . TestHelper::getServerConfig('mailDomainCorparate') .
                ',reporter1' . '@' . TestHelper::getServerConfig('mailDomainCorparate'),
        ], true);
    }

    public function testView()
    {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $this->readEntity('discussion', $id, $this->discussionSchema);
    }

    public function testAll()
    {
        $this->authByNewUser();
        $this->readCollection('discussion', [], $this->discussionSchema, 1);
    }

    public function testSearchBySubject()
    {
        $this->authByNewUser();
        $this->readCollection('discussion', ['search[subject]' => 'discussion subject'], $this->discussionSchema, 1);
        $phone = CurrentPhoneTestHelper::get();
        $this->readCollection('discussion', ['search[subject]' => $phone], $this->discussionSchema, 1);
    }

    public function testSearchBySubjectEmpty()
    {
        $this->authByNewUser();
        $this->readCollection('discussion', ['search[subject]' => 'fake'], $this->discussionSchema, 0);
    }

    public function testUpdate()
    {
        $phone = CurrentPhoneTestHelper::get();
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $this->updateEntity('discussion', $id, [
            'subject' => 'test discussion subject 111 ' . $phone,
            'description' => 'test discussion description 111',
        ]);
        $actual = $this->readEntity('discussion', $id, $this->discussionSchema);
        $this->tester->assertArraySubset([
            'subject' => 'test discussion subject 111 ' . $phone,
            'description' => 'test discussion description 111',
        ], $actual);
    }

    public function testDelete()
    {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $this->deleteEntity('discussion', $id);
        $this->readNotFoundEntity('discussion', $id);
    }

    /**
     * Для одного собеседника дискуссия не должна создаваться
     */
    public function testCreateForOneMember() {
        if(TestHelper::isSkipBug()) return;
        $phone = CurrentPhoneTestHelper::get();
        $this->authByNewUser();
        $this->createEntityUnProcessible('discussion', [
            'subject' => 'test discussion subject ' . $phone,
            'description' => 'test discussion description',
            'member_emails' => 'tester1' . '@' . TestHelper::getServerConfig('mailDomainCorparate'),
        ], ['member_emails']);
    }

    /**
     * Без темы дискуссия не должна создаваться
     */
    public function testCreateEmpty() {
        if(TestHelper::isSkipBug()) return;
        $this->authByNewUser();
        $this->createEntityUnProcessible('discussion', [
            'member_emails' =>
                'tester1' . '@' . TestHelper::getServerConfig('mailDomainCorparate') .
                ',tester2' . '@' . TestHelper::getServerConfig('mailDomainCorparate') .
                ',reporter1' . '@' . TestHelper::getServerConfig('mailDomainCorparate'),
        ], ['subject']);
    }

}
