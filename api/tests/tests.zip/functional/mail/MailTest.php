<?php

namespace tests\functional\mail;

use api\tests\schemas\MailSchema;
use yii2lab\rest\domain\entities\RequestEntity;
use yii2lab\test\helpers\CurrentIdTestHelper;
use yii2lab\test\helpers\TestHelper;
use yii2lab\test\Test\BaseActiveApiTest;
use yii2rails\extension\web\enums\HttpMethodEnum;
use yii2rails\extension\yii\helpers\FileHelper;
use yii2module\account\domain\v3\helpers\test\AuthTestHelper;
use yii2module\account\domain\v3\helpers\test\CurrentPhoneTestHelper;
use yii2module\account\domain\v3\helpers\test\RegistrationTestHelper;

// todo: проверять почту оппонента

class MailTest extends BaseActiveApiTest
{

    public $package = 'api';
    public $point = 'v1';

    public function testLoadFixture()
    {
        TestHelper::copySqlite(FileHelper::up(__DIR__), false);
    }

    public function testCreateUser()
    {
        RegistrationTestHelper::registration();
    }

    public function testSend() {
        $this->authByNewUser();
        $this->createEntity('mail', [
            'to' => 'tester' . '@' . TestHelper::getServerConfig('mailDomainPersonal') . ',tester1' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
            'subject' => 'subject1 test',
            'content' => 'content1 test',
        ]);
        $this->createEntity('mail', [
            'to' => 'tester2' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
            'subject' => 'subject2 test',
            'content' => 'content2 test',
        ]);
        $this->createEntity('mail', [
            'to' => 'reporter1' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
            'subject' => 'subject3 test',
            'content' => 'content3 test',
        ]);
        $this->createEntity('mail', [
            'to' => 'reporter2' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
            'subject' => 'subject4 test',
            'content' => 'content4 test',
        ]);
    }

    public function testAllNotReaded()
    {
        $this->authByNewUser();
        $this->readCollection('mail', ['seen' => 0], MailSchema::$flow, 0);
    }

    public function testAllReaded()
    {
        $this->authByNewUser();
        $this->readCollection('mail', ['seen' => 1], MailSchema::$flow, 4);
    }

    public function testSearchByText()
    {
        $this->authByNewUser();
        $this->readCollection('mail', ['search[text]' => 'test'], MailSchema::$flow, 4);
        $this->readCollection('mail', ['search[text]' => 'qwerty'], MailSchema::$flow, 0);
    }

    public function testSearchByTo()
    {
        $this->authByNewUser();
        $this->readCollection('mail', ['search[to]' => 'reporter'], MailSchema::$flow, 2);
        $this->readCollection('mail', ['search[to]' => 'tester'], MailSchema::$flow, 2);
        $this->readCollection('mail', ['search[to]' => 'qwerty'], MailSchema::$flow, 0);
        $this->readCollection('mail', ['search[text]' => 'reporter'], MailSchema::$flow, 2);
        $this->readCollection('mail', ['search[text]' => 'tester'], MailSchema::$flow, 2);
    }

    public function testSearchBySubject()
    {
        $this->authByNewUser();
        $this->readCollection('mail', ['search[subject]' => 'test'], MailSchema::$flow, 4);
        $this->readCollection('mail', ['search[subject]' => 'subject3'], MailSchema::$flow, 1);
        $this->readCollection('mail', ['search[subject]' => 'qwerty'], MailSchema::$flow, 0);
        $this->readCollection('mail', ['search[text]' => 'test'], MailSchema::$flow, 4);
        $this->readCollection('mail', ['search[text]' => 'subject3'], MailSchema::$flow, 1);
    }

    public function testSearchByContent()
    {
        $this->authByNewUser();
        $this->readCollection('mail', ['search[content]' => 'content'], MailSchema::$flow, 4);
        $this->readCollection('mail', ['search[content]' => 'content2'], MailSchema::$flow, 1);
        $this->readCollection('mail', ['search[content]' => 'qwerty'], MailSchema::$flow, 0);
        $this->readCollection('mail', ['search[text]' => 'content'], MailSchema::$flow, 4);
        $this->readCollection('mail', ['search[text]' => 'content2'], MailSchema::$flow, 1);
    }

    public function testSetLastId()
    {
        $phone = CurrentPhoneTestHelper::get();
        AuthTestHelper::authByLogin('test' . $phone);

        $requestEntity = new RequestEntity;
        $requestEntity->uri = 'mail';
        $requestEntity->method = HttpMethodEnum::GET;
        $responseEntity = $this->sendRequest($requestEntity);
        $this->tester->assertEquals(200, $responseEntity->status_code);
        $actual = $responseEntity->data;
        $lastId = $actual[0]['id'];
        $lastId = intval($lastId);
        CurrentIdTestHelper::set($lastId);
    }

    public function testAll()
    {
        $this->authByNewUser();
        $actual = $this->readCollection('mail', [], MailSchema::$flow, 4);
        $expect = [
            [
                'direct' => 'output',
                'folder' => 'outbox',
                'to' => [
                    'tester' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
                    'tester1' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
                ],
                'subject' => 'subject1 test',
                'short_content' => 'content1 test',
                'content' => 'content1 test',
            ],
            [
                'direct' => 'output',
                'folder' => 'outbox',
                'to' => [
                    'tester2' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
                ],
                'subject' => 'subject2 test',
                'short_content' => 'content2 test',
                'content' => 'content2 test',
            ],
            [
                'direct' => 'output',
                'folder' => 'outbox',
                'to' => [
                    'reporter1' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
                ],
                'subject' => 'subject3 test',
                'short_content' => 'content3 test',
                'content' => 'content3 test',
            ],
            [
                'direct' => 'output',
                'folder' => 'outbox',
                'to' => [
                    'reporter2' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
                ],
                'subject' => 'subject4 test',
                'short_content' => 'content4 test',
                'content' => 'content4 test',
            ],
        ];
        $this->tester->assertArraySubset($expect, $actual);
    }

    public function testMoveToTrash()
    {
        $this->authByNewUser();
        $id = CurrentIdTestHelper::get();
        $this->readCollection('mail', ['folder' => 'trash'], MailSchema::$flow, 0);
        $this->updateEntity('mail', $id, ['folder' => 'trash']);
        $this->readCollection('mail', ['folder' => 'trash'], MailSchema::$flow, 1);
    }

    public function testMoveToArchive()
    {
        $this->authByNewUser();
        $id = CurrentIdTestHelper::get();
        $this->readCollection('mail', ['folder' => 'archive'], MailSchema::$flow, 0);
        $this->updateEntity('mail', $id, ['folder' => 'archive']);
        $this->readCollection('mail', ['folder' => 'archive'], MailSchema::$flow, 1);
    }

    public function testMoveToSpam()
    {
        $this->authByNewUser();
        $id = CurrentIdTestHelper::get();
        $this->readCollection('mail', ['folder' => 'spam'], MailSchema::$flow, 0);
        $this->updateEntity('mail', $id, ['folder' => 'spam']);
        $this->readCollection('mail', ['folder' => 'spam'], MailSchema::$flow, 1);
    }

    public function testMoveToFlagged()
    {
        $this->authByNewUser();
        $id = CurrentIdTestHelper::get();
        $this->readCollection('mail', ['flagged' => 1], MailSchema::$flow, 0);
        $this->updateEntity('mail', $id, ['flagged' => 1]);
        $this->readCollection('mail', ['flagged' => 1], MailSchema::$flow, 1);
    }

    public function testDelete()
    {
        $this->authByNewUser();
        $id = CurrentIdTestHelper::get();
        $this->deleteEntity('mail', $id);
        $this->readNotFoundEntity('mail', $id);
        $this->readCollection('mail', [], MailSchema::$flow, 3);
    }

    public function testSendToSelf() {
        $this->authByNewUser();
        $phone = CurrentPhoneTestHelper::get();
        $this->createEntity('mail', [
            'to' => 'test' . $phone . '' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
            'subject' => 'subject test',
            'content' => 'content test',
        ]);
    }

}
