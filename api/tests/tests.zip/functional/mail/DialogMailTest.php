<?php

namespace tests\functional\mail;

use api\tests\schemas\DialogSchema;
use api\tests\schemas\MailSchema;
use yii2lab\test\helpers\CurrentIdTestHelper;
use yii2lab\test\helpers\TestHelper;
use yii2lab\test\Test\BaseActiveApiTest;
use yii2rails\extension\yii\helpers\FileHelper;
use yii2module\account\domain\v3\helpers\test\RegistrationTestHelper;

class DialogMailTest extends BaseActiveApiTest
{

    public $package = 'api';
    public $point = 'v1';

    public function testLoadFixture()
    {
        TestHelper::copySqlite(FileHelper::up(__DIR__), false);
    }

    public function testCreateUser()
    {
        RegistrationTestHelper::registration();
    }

    public function testCreateDialog() {
        $this->authByNewUser();
        $this->createEntity('dialog', [
            'contractor' => 'tester1' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
        ], true);
    }

    public function testViewBeforeSend()
    {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $this->readEntity('dialog', $id, DialogSchema::$dialog);
    }

    public function testSendMailToDialog() {
        $this->authByNewUser();
        $id = CurrentIdTestHelper::get();
        $this->createEntity('mail', [
            //'to' => 'tester1' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
            'subject' => 'subject test',
            'content' => 'content test to dialog',
            'dialog_id' => $id,
        ]);
        $this->readCollection('mail', ['dialog_id' => $id], MailSchema::$flow, 1);
        $actual = $this->readEntity('dialog', $id, DialogSchema::$dialog);
        if(TestHelper::isSkipBug()) {
            $expect = [
                'last_message' => 'content test to dialog',
            ];
        } else {
            $expect = [
                'new_message_count' => 1,
                'last_message' => 'content test to dialog',
            ];
        }
        $this->tester->assertArraySubset($expect, $actual);
    }

    public function testSendMailToDialogByTo() {
        $this->authByNewUser();
        $this->createEntity('mail', [
            'to' => 'tester1' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
            'subject' => 'subject test',
            'content' => 'content test to dialog 1',
        ]);
    }

    public function testAllMailsByDialogId()
    {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $this->readCollection('mail', ['dialog_id' => $id], MailSchema::$flow, 2);
    }

}
