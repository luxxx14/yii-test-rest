<?php

namespace tests\functional\mail;

use api\tests\schemas\MailSchema;
use PhpImap\Mailbox;
use yii2lab\test\helpers\TestHelper;
use yii2lab\test\Test\BaseActiveApiTest;
use yii2rails\extension\common\helpers\StringHelper;
use yii2rails\extension\web\enums\HttpMethodEnum;
use yii2rails\extension\yii\helpers\FileHelper;
use yubundle\account\domain\v2\entities\LoginEntity;
use yii2module\account\domain\v3\helpers\test\AuthTestHelper;
use yii2module\account\domain\v3\helpers\test\RegistrationTestHelper;

/*
Configure env-local.php:
'test' => [
    'mail' => [
        'pop3' => [
            'host' => 'pop.mail.ru',
            'username' => 'tester_yuwert@mail.ru',
            'password' => 'Wwwqqq111',
        ],
        'smtp' => [
            'host' => 'ssl://smtp.mail.ru',
            'username' => 'tester_yuwert@mail.ru',
            'password' => 'Wwwqqq111',
            'port' => '465',
        ],
    ],
],
 */

class MailExternalTest extends BaseActiveApiTest
{

    public $package = 'api';
    public $point = 'v1';

    public function _testLoadFixture()
    {
        TestHelper::copySqlite(FileHelper::up(__DIR__), false);
    }

    public function testCreateUser()
    {
        RegistrationTestHelper::registration();
    }

    public function testReceiveExternalMailEmpty()
    {
        $mailSenderToken = TestHelper::getServerConfig('mailServer.token');
        AuthTestHelper::authByToken($mailSenderToken);
        $this->createEntityUnProcessible('mail-receiver-form', [
            'subject' => 'subject test',
            'content' => 'content test',
        ], ['to', 'from']);
    }

    public function testReceiveExternalMail()
    {
        $this->cleanMessages('at_tester2');

        $mailSenderToken = TestHelper::getServerConfig('mailServer.token');
        AuthTestHelper::authByToken($mailSenderToken);
        $this->createEntity('mail-receiver-form', [
            'from' => 'test@yandex.ru',
            'to' => 'at_tester2@test.company',
            'subject' => 'subject test',
            'content' => 'content test',
        ]);
        //if(TestHelper::isSkipBug()) return;
        $this->authByAtUser('at_tester2');
        $this->readCollection('mail', [], MailSchema::$flow, 1);
    }

    public function testToExternalMail()
    {
        if(TestHelper::isSkipMode(['dev', 'test'])) return;
        $this->authByNewUser();
        $subject = "autotest send " . date('Y-m-d H:i:s', TIMESTAMP);
        $pop = TestHelper::getEnvLocalConfig('test.mail.pop3');
        if(empty($pop)) {
            TestHelper::printMessage('Need configure POP3!');
            return;
        }
        $this->createEntity('mail', [
            'to' => $pop['username'],
            'subject' => $subject,
            'content' => StringHelper::generateRandomString(32),
        ]);
        $isTrue = $this->getExternalMail($subject);
        $this->tester->assertTrue($isTrue);
    }

    public function testFromExternalMail()
    {
        if(TestHelper::isSkipMode(['dev', 'test'])) return;
        if(TestHelper::isSkipBug()) return;
        $this->authByNewUser();
        $this->readCollection('mail', [], MailSchema::$flow, 0);
        $smtp = TestHelper::getEnvLocalConfig('test.mail.smtp');
        $smtp['class'] = 'Swift_SmtpTransport';

        $definition = [
            'class' => 'yii\swiftmailer\Mailer',
            'viewPath' => '@common/mail',
            'useFileTransport' => false,
            'transport' => $smtp,
        ];

        /** @var \yii\swiftmailer\Mailer $mailer */
        $mailer = \Yii::createObject($definition);

        $subject = "autotest receive " . date('Y-m-d H:i:s', TIMESTAMP);

        $mailer->compose()
            ->setFrom($smtp['username'])
            ->setTo('tester' . '@' . TestHelper::getServerConfig('mailDomainCorparate'))
            ->setSubject($subject)
            ->setTextBody(StringHelper::generateRandomString(32))
            ->send();
        $hasNewMessage = $this->waitNewMessage($subject);
        $this->tester->assertTrue($hasNewMessage);
        // todo: дописать тест проверки нового сообщения
    }

    private function getExternalMailItem($subject) {
        $pop = TestHelper::getEnvLocalConfig('test.mail.pop3');
        $mailbox = new Mailbox('{'.$pop['host'].':995/novalidate-cert/pop3/ssl}INBOX', $pop['username'], $pop['password'], __DIR__);
        $mailsIds = $mailbox->searchMailbox('SUBJECT "'.$subject.'"');
        if($mailsIds) {
            $mail = $mailbox->getMail($mailsIds[0]);
            if($mail->subject == $subject) {
                return true;
            }
        }
        return false;
    }

    private function getExternalMail($subject) {
        for ($i = 0; $i < 3; $i++) {
            sleep(2);
            $isTrue = $this->getExternalMailItem($subject);
            if($isTrue) {
                return true;
            }
        }
        return false;
    }

    private function waitNewMessage($subject) {
        $smtp = TestHelper::getEnvLocalConfig('test.mail.smtp');
        for ($i = 0; $i < 3; $i++) {
            sleep(2);
            $actual = $this->readCollection('mail', ['search[subject]' => $subject], MailSchema::$flow);
            if(!empty($actual)) {
                $this->tester->assertArraySubset([
                    "direct" => "input",
                    'from' => $smtp['username'],
                ], $actual[0]);
                return true;
            }
        }
        return false;
    }


    private function cleanMessages($login) {
        $this->authByAtUser($login);
        $mailCollection = $this->readCollection('mail', [], MailSchema::$flow);
        foreach ($mailCollection as $mail) {
            $this->send('mail' . SL . $mail['id'], HttpMethodEnum::DELETE);
        }
        $this->readCollection('mail', [], MailSchema::$flow, 0);
    }

}
