<?php

namespace tests\functional\mail;

use api\tests\schemas\MailSchema;
use yii2lab\rest\domain\entities\RequestEntity;
use yii2lab\test\enums\TypeEnum;
use yii2lab\test\helpers\CurrentIdTestHelper;
use yii2lab\test\helpers\TestHelper;
use yii2lab\test\Test\BaseActiveApiTest;
use yii2rails\extension\web\enums\HttpHeaderEnum;
use yii2rails\extension\web\enums\HttpMethodEnum;
use yii2rails\extension\yii\helpers\FileHelper;
use yii2module\account\domain\v3\helpers\test\RegistrationTestHelper;

// todo: отправка картинок в теле сообщения

class DraftTest extends BaseActiveApiTest
{

    public $package = 'api';
    public $point = 'v1';

    public function testLoadFixture()
    {
        TestHelper::copySqlite(FileHelper::up(__DIR__), false);
    }

    public function testCreateUser()
    {
        RegistrationTestHelper::registration();
    }

    public function testSendMail() {
        $this->authByNewUser();
        $this->readCollection('mail', [], MailSchema::$flow, 0);
        $this->createEntity('draft', [
            'to' => 'tester' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
            'subject' => 'subject test',
            'content' => 'content test',
        ], true);
        $id = CurrentIdTestHelper::get();
        $this->createEntity('draft/send/' . $id, [
            'to' => 'tester1' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
            'subject' => 'subject test',
            'content' => 'content test',
        ]);
        $this->readCollection('mail', [], MailSchema::$flow, 1);
    }

    public function testCreateDraftWithAttachment() {
        $this->authByNewUser();

        // создание писма
        $this->createEntity('draft', [
            'to' => 'testeryuwert@gmail.com',
            'subject' => 'subject test with attachment',
            'content' => 'content test with attachment',
        ], true);

        // Прикреп файла к письму
        $id = CurrentIdTestHelper::get();
        $requestEntity = new RequestEntity;
        $requestEntity->uri = 'draft-attachment';
        $requestEntity->method = HttpMethodEnum::POST;
        $requestEntity->data = [
            'mail_id' => $id,
        ];
        $requestEntity->files = [
            'file' => ROOT_DIR . '/yii',
        ];
        $responseEntity = $this->sendRequest($requestEntity);
        //d($responseEntity);
        $this->tester->assertEquals(201, $responseEntity->status_code);
        $lastId = $responseEntity->headers['x-entity-id'];
        $this->tester->assertNotEmpty($lastId);
        $lastId = intval($lastId);
        $this->tester->assertType('lastId', TypeEnum::INTEGER, $lastId);
    }

    public function testViewAttachment() {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $actual = $this->readEntity('draft', $id, MailSchema::$mail, ['expand' => 'attachments']);
        $this->tester->assertCollectionType(MailSchema::$attachment, $actual['attachments']);
        $expect = [
            [
                'path' => 'storage/mail/attachment/'.$id.'/source/yii',
                'extension' => '',
                'size' => '236',
                'status' => '1',
                //'url' => 'http://test-web.yumail.kz/storage/mail/attachment/'.$id.'/source/yii',
                'file_name' => 'yii',
            ],
        ];
        $this->tester->assertArraySubset($expect, $actual['attachments']);
        $this->tester->assertRegExp('#https?://(.+)/storage/mail/attachment/'.$id.'/source/yii#', $actual['attachments'][0]['url']);

        $actualContent = file_get_contents($actual['attachments'][0]['url']);
        $expectContent = file_get_contents(ROOT_DIR . '/yii');
        $this->tester->assertEquals($expectContent, $actualContent);
    }

    public function testUpdateDraft() {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $this->updateEntity('draft', $id, [
            'to' => 'tester1' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
            'subject' => 'subject test with attachment 2',
            'content' => 'content test with attachment 2',
        ]);
        $actual = $this->readEntity('draft', $id, MailSchema::$mail);
        $this->tester->assertArraySubset([
            'to' => [
                'tester1' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
            ],
            'subject' => 'subject test with attachment 2',
            'content' => 'content test with attachment 2',
        ], $actual);
    }

    public function testSend() {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $this->createEntity('draft/send/' . $id, [
            'to' => 'tester1' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
            'subject' => 'subject test with attachment 2',
            'content' => 'content test with attachment 2',
        ]);

        $responseEntity = $this->send('draft/send/' . $id, HttpMethodEnum::POST, [
            'to' => 'tester1' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
            'subject' => 'subject test with attachment 2',
            'content' => 'content test with attachment 2',
        ]);
        $this->tester->assertEquals(500, $responseEntity->status_code);
        $this->tester->assertEquals('Сообщения нельзя модифицировать после отправки', $responseEntity->data['message']);
    }

    public function testAllWithAttachments()
    {
        $this->authByNewUser();
        $actual = $this->readCollection('mail', ['has_attachment' => 1], MailSchema::$flow, 1);
        $expect = [
            [
                'direct' => 'output',
                'folder' => 'outbox',
                'to' => [
                    'tester1' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
                ],
                'subject' => 'subject test with attachment 2',
                'short_content' => 'content test with attachment 2',
                'content' => 'content test with attachment 2',
            ],
        ];
        $this->tester->assertArraySubset($expect, $actual);
    }

    public function testAllNotWithAttachments()
    {
        $this->authByNewUser();
        $actual = $this->readCollection('mail', ['has_attachment' => 0], MailSchema::$flow, 1);
        $expect = [
            [
                'to' => [
                    'tester1' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
                ],
                'subject' => 'subject test',
                'short_content' => 'content test',
                'content' => 'content test',
                'has_attachment' => false,
                'has_attachments' => false,
            ],
        ];
        $this->tester->assertArraySubset($expect, $actual);
    }

    public function testDeleteAfterSend() {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();

        $requestEntity = new RequestEntity;
        $requestEntity->uri = 'draft/send/' . $id;
        $requestEntity->method = HttpMethodEnum::DELETE;
        $responseEntity = $this->sendRequest($requestEntity);
        $this->tester->assertEquals(404, $responseEntity->status_code);
    }

    public function testAll() {
        $this->authByNewUser();
        $this->readCollection('mail', [], MailSchema::$flow, 2);
    }

    public function testCreateDraftWithAttachment1() {
        $this->authByNewUser();

        // создание писма
        $this->createEntity('draft', [
            'to' => 'testeryuwert@gmail.com',
            'subject' => 'subject test with attachment',
            'content' => 'content test with attachment',
        ], true);

        // Прикреп файла к письму
        $id = CurrentIdTestHelper::get();
        $requestEntity = new RequestEntity;
        $requestEntity->uri = 'draft-attachment';
        $requestEntity->method = HttpMethodEnum::POST;
        $requestEntity->data = [
            'mail_id' => $id,
        ];
        $requestEntity->files = [
            'file' => ROOT_DIR . '/composer.json',
        ];
        $responseEntity = $this->sendRequest($requestEntity);
        //d($responseEntity);
        $this->tester->assertEquals(201, $responseEntity->status_code);
        $lastId = $responseEntity->headers['x-entity-id'];
        $this->tester->assertNotEmpty($lastId);
        $lastId = intval($lastId);
        $this->tester->assertType('lastId', TypeEnum::INTEGER, $lastId);
    }

    public function testViewAttachment1() {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $actual = $this->readEntity('draft', $id, MailSchema::$mail, ['expand' => 'attachments']);
        $this->tester->assertCollectionType(MailSchema::$attachment, $actual['attachments']);
        $expect = [
            [
                'path' => 'storage/mail/attachment/'.$id.'/source/composer.json',
                'extension' => 'json',
                'size' => '6161',
                'status' => '1',
                //'url' => 'http://test-web.yumail.kz/storage/mail/attachment/'.$id.'/source/composer.json',
                'file_name' => 'composer.json',
            ],
        ];
        $this->tester->assertArraySubset($expect, $actual['attachments']);
        $this->tester->assertRegExp('#https?://(.+)/storage/mail/attachment/'.$id.'/source/composer.json#', $actual['attachments'][0]['url']);

        $actualContent = file_get_contents($actual['attachments'][0]['url']);
        $expectContent = file_get_contents(ROOT_DIR . '/composer.json');
        $this->tester->assertEquals($expectContent, $actualContent);
    }

    public function testCreateDraftWithAttachment2() {
        $this->authByNewUser();

        // создание писма
        $this->createEntity('draft', [
            'to' => 'testeryuwert@gmail.com',
            'subject' => 'subject test with attachment',
            'content' => 'content test with attachment',
        ], true);

        // Прикреп файла к письму
        $id = CurrentIdTestHelper::get();
        $requestEntity = new RequestEntity;
        $requestEntity->uri = 'draft-attachment';
        $requestEntity->method = HttpMethodEnum::POST;
        $requestEntity->data = [
            'mail_id' => $id,
        ];
        $requestEntity->files = [
            'file' => ROOT_DIR . '/api/tests/_data/кирилица.txt',
        ];
        $responseEntity = $this->sendRequest($requestEntity);
        //d($responseEntity);
        $this->tester->assertEquals(201, $responseEntity->status_code);
        $lastId = $responseEntity->headers['x-entity-id'];
        $this->tester->assertNotEmpty($lastId);
        $lastId = intval($lastId);
        $this->tester->assertType('lastId', TypeEnum::INTEGER, $lastId);
    }

    public function testViewAttachment2() {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $actual = $this->readEntity('draft', $id, MailSchema::$mail, ['expand' => 'attachments']);
        $this->tester->assertCollectionType(MailSchema::$attachment, $actual['attachments']);
        $expect = [
            [
                'path' => 'storage/mail/attachment/'.$id.'/source/кирилица.txt',
                'extension' => 'txt',
                'size' => '8',
                'status' => '1',
                //'url' => 'http://test-web.yumail.kz/storage/mail/attachment/'.$id.'/source/кирилица.txt',
                'file_name' => 'кирилица.txt',
            ],
        ];
        $this->tester->assertArraySubset($expect, $actual['attachments']);
        $this->tester->assertRegExp('#https?://(.+)/storage/mail/attachment/'.$id.'/source/кирилица.txt#', $actual['attachments'][0]['url']);

        $actualContent = file_get_contents($actual['attachments'][0]['url']);
        $expectContent = file_get_contents(ROOT_DIR . '/api/tests/_data/кирилица.txt');
        $this->tester->assertEquals($expectContent, $actualContent);
    }

}
