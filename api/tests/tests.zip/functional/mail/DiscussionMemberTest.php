<?php

namespace tests\functional\mail;

use common\enums\rbac\RoleEnum;
use domain\mail\v1\entities\DiscussionMemberEntity;
use domain\mail\v1\enums\MemberEnum;
use yii2lab\test\enums\TypeEnum;
use yii2lab\test\helpers\CurrentIdTestHelper;
use yii2lab\test\helpers\TestHelper;
use yii2lab\test\Test\BaseActiveApiTest;
use yii2rails\extension\web\enums\HttpMethodEnum;
use yii2rails\extension\yii\helpers\FileHelper;
use yii2module\account\domain\v3\helpers\test\CurrentPhoneTestHelper;
use yii2module\account\domain\v3\helpers\test\RegistrationTestHelper;
use yubundle\account\domain\v2\helpers\test\AuthTestHelper;

// todo: смена роли участника
// todo: удаление участника

class DiscussionMemberTest extends BaseActiveApiTest
{

    public $package = 'api';
    public $point = 'v1';

    private $discussionSchema = [
        'id' => TypeEnum::INTEGER,
        'corporate_client_id' => [TypeEnum::INTEGER,TypeEnum::NULL],
        'subject' => TypeEnum::STRING,
        'description' => TypeEnum::STRING,
        'members' => [TypeEnum::ARRAY,TypeEnum::NULL],
        'mails' => TypeEnum::NULL,
        'status' => TypeEnum::INTEGER,
        'created_at' => TypeEnum::TIME,
        'updated_at' => TypeEnum::TIME,
        'last_message' => TypeEnum::STRING,
    ];

    private $memberSchema = [
        'id' => TypeEnum::INTEGER,
        'discussion_id' => TypeEnum::INTEGER,
        'email' => TypeEnum::STRING,
        'role' => TypeEnum::STRING,
        'created_at' => TypeEnum::TIME,
        'updated_at' => TypeEnum::TIME,
        'status' => TypeEnum::INTEGER,
    ];

    public function testLoadFixture()
    {
        TestHelper::copySqlite(FileHelper::up(__DIR__), false);
    }

    public function testCreateUser()
    {
        RegistrationTestHelper::registration();
    }

    public function testCreate() {
        $phone = CurrentPhoneTestHelper::get();
        $this->authByNewUser();

        $this->createEntity('discussion', [
            'subject' => 'test discussion subject ' . $phone,
            'description' => 'test discussion description',
            'member_emails' =>
                'tester1' . '@' . TestHelper::getServerConfig('mailDomainPersonal') .
                ',tester2' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
        ], true);
    }

    public function testView()
    {
        $phone = CurrentPhoneTestHelper::get();
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $actual = $this->readEntity('discussion', $id, $this->discussionSchema, ['expand' => 'members']);
        $this->tester->assertCollectionType($this->memberSchema, $actual['members']);
        $this->tester->assertArraySubset([
            [
                'discussion_id' => $id,
                'email' => 'test' . $phone . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
                'role' => 'creator',
                'status' => '1',
            ],
            [
                'discussion_id' => $id,
                'email' => 'tester1' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
                'role' => 'member',
                'status' => '1',
            ],
            [
                'discussion_id' => $id,
                'email' => 'tester2' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
                'role' => 'member',
                'status' => '1',
            ],
        ], $actual['members']);
    }

    public function testDeleteSelf() {
        $discussionId = CurrentIdTestHelper::get();
        $member = $this->getMembersByRole($discussionId, MemberEnum::CREATOR);
        $id = $member[0]['id'];
        $responseEntity = $this->send('discussion-member' . SL . $id, HttpMethodEnum::DELETE);
        $this->tester->assertEquals(400, $responseEntity->status_code);
    }

    /**
     * Удаление участника, если их всего 3
     */
    public function testDeleteMemberFail() {
        $discussionId = CurrentIdTestHelper::get();
        $member = $this->getMembersByRole($discussionId, MemberEnum::MEMBER);
        $id = $member[0]['id'];
        $responseEntity = $this->send('discussion-member' . SL . $id, HttpMethodEnum::DELETE);
        $this->tester->assertEquals(400, $responseEntity->status_code);
    }

    public function testAddMember()
    {
        $phone = CurrentPhoneTestHelper::get();
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $this->createEntity('discussion-member', [
            'discussion_id' => $id,
            'email' => 'reporter2' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
        ]);
        $actual = $this->readEntity('discussion', $id, $this->discussionSchema, ['expand' => 'members']);
        $this->tester->assertCollectionType($this->memberSchema, $actual['members']);
        $this->tester->assertArraySubset([
            [
                'discussion_id' => $id,
                'email' => 'test' . $phone . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
                'role' => 'creator',
                'status' => '1',
            ],
            [
                'discussion_id' => $id,
                'email' => 'tester1' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
                'role' => 'member',
                'status' => '1',
            ],
            [
                'discussion_id' => $id,
                'email' => 'tester2' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
                'role' => 'member',
                'status' => '1',
            ],
            [
                'discussion_id' => $id,
                'email' => 'reporter2' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
                'role' => 'member',
                'status' => '1',
            ],
        ], $actual['members']);
    }

    public function testDeleteMember() {
        $discussionId = CurrentIdTestHelper::get();
        $member = $this->getMembersByRole($discussionId, MemberEnum::MEMBER);
        $id = $member[0]['id'];
        $this->deleteEntity('discussion-member', $id);
        $this->readNotFoundEntity('discussion-member', $id);
    }

    /**
     * TODO: Не работает переавторизация.
     * @throws \yii\web\UnauthorizedHttpException
     */
    public function testDeleteMemberByMember() {
        if (TestHelper::isSkipBug()) return;
        $discussionId = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $this->createEntity('discussion-member', [
            'discussion_id' => $discussionId,
            'email' => 'reporter2' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
        ]);
        AuthTestHelper::logout();
        AuthTestHelper::authByLogin('tester1');
        $member = $this->getMembersByRole($discussionId,MemberEnum::MEMBER);
        $id = $member[0]['id'];
        $responseEntity = $this->send('discussion-member' . SL . $id, HttpMethodEnum::DELETE);
        $this->tester->assertEquals(403, $responseEntity->status_code);
    }

    public function testDeleteAdminMemberByMember() {
        $discussionId = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $this->createEntity('discussion-member', [
            'discussion_id' => $discussionId,
            'email' => 'reporter1' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
        ]);
        AuthTestHelper::authByLogin('tester1');
        $member = $this->getMembersByRole($discussionId, MemberEnum::CREATOR);
        $id = $member[0]['id'];
        $responseEntity = $this->send('discussion-member' . SL . $id, HttpMethodEnum::DELETE);
        $this->tester->assertEquals(403, $responseEntity->status_code);
    }

    private function getMembersByRole($discussionId, $role) {
        return $this->readCollection('discussion-member', [
            'discussion_id' => $discussionId,
            'role' => $role,
            'sort' => 'email'
        ], $this->memberSchema);
    }

}
