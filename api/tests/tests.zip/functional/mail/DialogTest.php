<?php

namespace tests\functional\mail;

use api\tests\schemas\BoxSchema;
use api\tests\schemas\CompanySchema;
use api\tests\schemas\DialogSchema;
use api\tests\schemas\DomainSchema;
use api\tests\schemas\UserSchema;
use yii2lab\rest\domain\entities\RequestEntity;
use yii2lab\test\helpers\CurrentIdTestHelper;
use yii2lab\test\helpers\TestHelper;
use yii2lab\test\Test\BaseActiveApiTest;
use yii2rails\extension\web\enums\HttpMethodEnum;
use yii2rails\extension\yii\helpers\FileHelper;
use yii2module\account\domain\v3\helpers\test\CurrentPhoneTestHelper;
use yii2module\account\domain\v3\helpers\test\RegistrationTestHelper;

class DialogTest extends BaseActiveApiTest
{

    public $package = 'api';
    public $point = 'v1';

    public function testLoadFixture()
    {
        TestHelper::copySqlite(FileHelper::up(__DIR__), false);
    }

    public function testCreateUser()
    {
        RegistrationTestHelper::registration();
    }

    public function testCreateDialog() {
        $this->authByNewUser();
        $this->createEntity('dialog', [
            'contractor' => 'tester1@' . TestHelper::getServerConfig('mailDomainPersonal'),
        ], true);
    }

    public function testCreateDialogDouble() {
        // второй раз диалог создавать нельзя, но тут непонятно, баг или фитча, когда 201 статус
        if(TestHelper::isSkipBug()) return;
        $this->authByNewUser();
        $this->createEntityUnProcessible('dialog', [
            'contractor' => 'tester1@' . TestHelper::getServerConfig('mailDomainPersonal'),
        ], ['contractor']);
    }

    public function testCreateDialogByExternal() {
        $this->authByNewUser();

        $requestEntity = new RequestEntity;
        $requestEntity->uri = 'dialog';
        $requestEntity->method = HttpMethodEnum::POST;
        $requestEntity->data = [
            'contractor' => 'tester1@yandex.ru',
        ];
        $responseEntity = $this->sendRequest($requestEntity);
        $this->tester->assertEquals(422, $responseEntity->status_code);
        if(TestHelper::isSkipBug()) return;
        $this->tester->assertUnprocessableEntityExceptionFields(['contractor'], $responseEntity->data);
    }

    public function testCreateDialogByNotExistsBox() {
        $this->authByNewUser();

        $requestEntity = new RequestEntity;
        $requestEntity->uri = 'dialog';
        $requestEntity->method = HttpMethodEnum::POST;
        $requestEntity->data = [
            'contractor' => 'qwerty123456789' . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
        ];
        $responseEntity = $this->sendRequest($requestEntity);
        $this->tester->assertEquals(422, $responseEntity->status_code);
        if(TestHelper::isSkipBug()) return;
        $this->tester->assertUnprocessableEntityExceptionFields(['contractor'], $responseEntity->data);
    }

    public function testView()
    {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $actual = $this->readEntity('dialog', $id, DialogSchema::$dialog);
        $this->tester->assertArraySubset([
            'flagged' => 0,
        ], $actual);
        /*$this->assertRelationContract('dialog', $id, [
            'box' => BoxSchema::$box,
            'box.person' => UserSchema::$person,
            'box.person.user' => UserSchema::$identity,
            'box.domain' => DomainSchema::$domain,
            'box.domain.company' => CompanySchema::$company,
        ]);*/
    }

    public function testAll()
    {
        $this->authByNewUser();
        $this->readCollection('dialog', [], DialogSchema::$dialog, 1);
    }

    public function testAllByContractor()
    {
        $this->authByNewUser();
        $this->readCollection('dialog', ['contractor' => 'tester1@' . TestHelper::getServerConfig('mailDomainPersonal')], DialogSchema::$dialog, 1);
    }

    public function testSearchByFullName()
    {
        $this->authByNewUser();
        $this->readCollection('dialog', ['search[full_name]' => 'tester'], DialogSchema::$dialog, 1);
    }

    public function testSearchByFullNameEmpty()
    {
        $this->authByNewUser();
        $this->readCollection('dialog', ['search[full_name]' => 'qwertyu'], DialogSchema::$dialog, 0);
    }

    public function testAddToFavorite()
    {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $this->updateEntity('dialog', $id, ['flagged' => 1]);
    }

    public function testViewFavorite()
    {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $actual = $this->readEntity('dialog', $id, DialogSchema::$dialog);
        $this->tester->assertArraySubset([
            'flagged' => 1,
        ], $actual);
    }

    public function testDelete()
    {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $this->deleteEntity('dialog', $id);
    }

    public function testViewAfterDelete()
    {
        $id = CurrentIdTestHelper::get();
        $this->authByNewUser();
        $this->readNotFoundEntity('dialog', $id);
    }

    public function testCreateDialogForSelf() {
        // создавать диалог с самим собой баг или фитча?
        //if(TestHelper::isSkipBug()) return;
        $this->authByNewUser();
        $phone = CurrentPhoneTestHelper::get();
        $this->createEntity('dialog', [
            'contractor' => 'test' . $phone  . '@' . TestHelper::getServerConfig('mailDomainPersonal'),
        ]);
    }

}
