<?php

namespace tests\functional\staff;

use api\tests\schemas\CompanySchema;
use yii2lab\rest\domain\entities\RequestEntity;
use yii2lab\test\enums\TypeEnum;
use yii2lab\test\helpers\TestHelper;
use yii2lab\test\Test\BaseActiveApiTest;
use yii2rails\extension\web\enums\HttpMethodEnum;
use yii2rails\extension\yii\helpers\FileHelper;
use yii2module\account\domain\v3\helpers\test\AuthTestHelper;

class StaffDivisionTest extends BaseActiveApiTest
{

    public $package = 'api';
    public $point = 'v1';

    private $divisionSchema = [
        'id' => TypeEnum::INTEGER,
        'parent_id' => [TypeEnum::INTEGER, TypeEnum::NULL],
        'company_id' => TypeEnum::INTEGER,
        'name' => TypeEnum::STRING,
        'status' => TypeEnum::INTEGER,
        'created_at' => TypeEnum::TIME,
        'updated_at' => TypeEnum::TIME,
        'parent' => [TypeEnum::ARRAY, TypeEnum::NULL],
        'child' => [TypeEnum::ARRAY, TypeEnum::NULL],
        'company' => [TypeEnum::ARRAY, TypeEnum::NULL],
    ];

    public function testLoadFixture()
    {
        TestHelper::copySqlite(FileHelper::up(__DIR__), false);
    }

    public function testViewTreeByCorporateUser()
    {
        AuthTestHelper::authByLogin('nadya@' . TestHelper::getServerConfig('mailDomainCorparate'));

        $requestEntity = new RequestEntity;
        $requestEntity->uri = 'staff-division-tree';
        $requestEntity->method = HttpMethodEnum::GET;

        $responseEntity = $this->sendRequest($requestEntity);
        $this->tester->assertEquals(200, $responseEntity->status_code);
        $actual = $responseEntity->data;
        $this->tester->assertCollectionType($this->divisionSchema, $actual);

    }

    public function testViewTreeByNotCorporateUser()
    {
        AuthTestHelper::authByLogin('tester1' . '@' . TestHelper::getServerConfig('mailDomainPersonal'));

        $requestEntity = new RequestEntity;
        $requestEntity->uri = 'staff-division-tree';
        $requestEntity->method = HttpMethodEnum::GET;

        $responseEntity = $this->sendRequest($requestEntity);
        $this->tester->assertEquals(200, $responseEntity->status_code);
        // должен возвращаться 204 status_code
        $actual = $responseEntity->data;
        $this->tester->assertNull($actual);
    }

    public function testCollectionByCorporateUser()
    {
        AuthTestHelper::authByLogin('nadya@' . TestHelper::getServerConfig('mailDomainCorparate'));
        $this->readCollection('staff-division', [], $this->divisionSchema, 11);
    }

    public function testOneByCorporateUser()
    {
        AuthTestHelper::authByLogin('nadya@' . TestHelper::getServerConfig('mailDomainCorparate'));
        $this->readEntity('staff-division', 11, $this->divisionSchema);
    }

    public function testOneByCorporateUserWithCompany()
    {
        AuthTestHelper::authByLogin('nadya@' . TestHelper::getServerConfig('mailDomainCorparate'));
        $actual = $this->readEntity('staff-division', 11, $this->divisionSchema, ['expand'=>'company']);
        //if(TestHelper::isSkipBug()) return;
        // приходит коллекция вместо сущности
        $this->tester->assertArrayType(CompanySchema::$company, $actual['company']);
    }

    public function testOneByCorporateUserWithParent()
    {
        AuthTestHelper::authByLogin('nadya@' . TestHelper::getServerConfig('mailDomainCorparate'));
        $actual = $this->readEntity('staff-division', 13, $this->divisionSchema, ['expand'=>'parent']);
        $this->tester->assertArrayType($this->divisionSchema, $actual['parent']);
    }

    public function testOneByCorporateUserWithChild()
    {
        AuthTestHelper::authByLogin('nadya@' . TestHelper::getServerConfig('mailDomainCorparate'));
        $actual = $this->readEntity('staff-division', 11, $this->divisionSchema, ['expand'=>'child']);
        $this->tester->assertCollectionType($this->divisionSchema, $actual['child']);
    }

    public function testAllByIdsWithChildFieldsFilter()
    {
        AuthTestHelper::authByLogin('nadya@' . TestHelper::getServerConfig('mailDomainCorparate'));

        $this->assertRelationContract('staff-division', 13, ['parent' => $this->divisionSchema]);
    }

}
