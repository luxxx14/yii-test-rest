<?php

namespace tests\functional\staff;

use yii2lab\rest\domain\entities\RequestEntity;
use yii2lab\test\enums\TypeEnum;
use yii2lab\test\helpers\TestHelper;
use yii2lab\test\Test\BaseActiveApiTest;
use yii2rails\extension\web\enums\HttpMethodEnum;
use yii2rails\extension\yii\helpers\FileHelper;
use yii2module\account\domain\v3\helpers\test\AuthTestHelper;

class StaffWorkerTestTest extends BaseActiveApiTest
{

    public $package = 'api';
    public $point = 'v1';

    private $staffWorkerSchema = [
        'id' => TypeEnum::INTEGER,
        'person_id' => TypeEnum::INTEGER,
        'company_id' => TypeEnum::INTEGER,
        'email' => TypeEnum::STRING,
        'post_id' => TypeEnum::INTEGER,
        'division_id' => TypeEnum::INTEGER,
        'office' => [TypeEnum::STRING, TypeEnum::NULL],
        'phone' => [TypeEnum::STRING, TypeEnum::NULL],
        'status' => TypeEnum::INTEGER,
        'created_at' => TypeEnum::TIME,
        'updated_at' => TypeEnum::TIME,
        'corporate_email' => TypeEnum::STRING,
        'full_name' => TypeEnum::STRING,
        'division_name' => TypeEnum::STRING,
        'post_name' => TypeEnum::STRING,
    ];


    public function testLoadFixture()
    {
        TestHelper::copySqlite(FileHelper::up(__DIR__), false);
    }

    public function testAllByCorporateUser()
    {
        AuthTestHelper::authByLogin('nadya@' . TestHelper::getServerConfig('mailDomainCorparate'));
        $this->readCollection('staff-worker', [], $this->staffWorkerSchema, 11);
    }

    public function testViewTreeByNotCorporateUser()
    {
        AuthTestHelper::authByLogin('tester1' . '@' . TestHelper::getServerConfig('mailDomainPersonal'));
        $this->readCollection('staff-worker', [], $this->staffWorkerSchema, 0);
    }

    public function testOneByCorporateWorker()
    {
        AuthTestHelper::authByLogin('nadya@' . TestHelper::getServerConfig('mailDomainCorparate'));
        $this->readEntity('staff-worker', 4, $this->staffWorkerSchema);
    }

    public function testSearchStaffWorkerByName()
    {
        AuthTestHelper::authByLogin('nadya@' . TestHelper::getServerConfig('mailDomainCorparate'));
        $this->readCollection('staff-worker', ['search[name]' => 'Гул'], $this->staffWorkerSchema, 2);
    }

    public function testSearchStaffWorkerByPhone()
    {
        AuthTestHelper::authByLogin('nadya@' . TestHelper::getServerConfig('mailDomainCorparate'));
        $this->readCollection('staff-worker', ['search[phone]' => '77991111113'], $this->staffWorkerSchema, 1);
    }

}
