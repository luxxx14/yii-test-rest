<?php

namespace api\tests\schemas;

use yii2lab\test\enums\TypeEnum;

class DomainSchema
{

    public static $domain = [
        'id' => TypeEnum::INTEGER,
        'company_id' => TypeEnum::INTEGER,
        'domain' => TypeEnum::STRING,
        'host' => TypeEnum::STRING,
        'port' => TypeEnum::INTEGER,
        'status' => TypeEnum::INTEGER,
        'created_at' => TypeEnum::TIME,
        'updated_at' => TypeEnum::TIME,
        'company' => [TypeEnum::ARRAY,TypeEnum::NULL],
    ];

}
