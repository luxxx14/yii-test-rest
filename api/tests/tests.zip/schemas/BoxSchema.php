<?php

namespace api\tests\schemas;

use yii2lab\test\enums\TypeEnum;

class BoxSchema
{

    public static $box = [
        'id' => TypeEnum::INTEGER,
        'domain_id' => TypeEnum::INTEGER,
        'person_id' => TypeEnum::INTEGER,
        'email' => TypeEnum::STRING,
        'status' => TypeEnum::INTEGER,
        'created_at' => TypeEnum::TIME,
        'updated_at' => TypeEnum::TIME,
        'domain' => [TypeEnum::ARRAY,TypeEnum::NULL],
        'person' => [TypeEnum::ARRAY,TypeEnum::NULL],
    ];

}
